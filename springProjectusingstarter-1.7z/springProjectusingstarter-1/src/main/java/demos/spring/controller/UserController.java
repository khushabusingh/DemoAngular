package demos.spring.controller;

//public class UserController {
//
//}
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demos.spring.model.User;
import demos.spring.service.UserService;
@RestController
@CrossOrigin()
@RequestMapping("/api")
public class UserController {
	@Autowired
	private UserService us;
	
	@GetMapping("/users")
	public List<User> getAllUser(){
		return us.getAllUser();
	}
	@PostMapping("/create")
	public User add(@RequestBody User u) {
		return us.add(u);
	}
	@GetMapping("/users/{id}")
	public User getUserById(@PathVariable("id")int id) {
		return us.getUserById(id);
		
	}
	
	@PutMapping("/users/{id}")
	public User update(@PathVariable("id") int id,@RequestBody User user) {
		user.setUserId(id);
		return us.update(user);
	}
	@DeleteMapping("/users/{id}")

	public void delete(@PathVariable("id")int id) {
		us.delete(id);
	}
	@PostMapping("/login")
	public User loginUser(@RequestBody User user) throws Exception {
		String email=user.getEmail();
		String pass=user.getPassword();
		User usr=null;
		if(email !=null && pass != null) {
		 usr= us.findByEmailAndPassword(email, pass);
	}
		else {
			throw new Exception("incorrect credential");
		}
		return usr;
	}
}

