package demos.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demos.spring.model.Doctor;
import demos.spring.model.User;
import demos.spring.service.DoctorService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/doctor")
public class DoctorController {
	@Autowired
	private DoctorService ds;
	
	@GetMapping("/all")
	public List<Doctor> getAllDoctor(){
		return ds.getAllDoctor();
	}
	
	@PostMapping("/create")
	public Doctor add(@RequestBody Doctor d) {
		return ds.add(d);
	}
	@GetMapping("/users/{id}")
	public Doctor getDoctorById(@PathVariable("id")int id) {
		return ds.getDoctorById(id);
		
	}
	@PutMapping("/doctorUpdate/{id}")
	public Doctor update(@PathVariable("id") int id,@RequestBody Doctor doctor) {
		doctor.setdId(id);
		return ds.update(doctor);
	}
	@DeleteMapping("/delete/{id}")

	public void delete(@PathVariable("id")int id) {
		ds.delete(id);
	}
	@PostMapping("/login")
	public Doctor loginUser(@RequestBody Doctor doctor) throws Exception {
		String email=doctor.getEmail();
		String pass=doctor.getPassword();
		Doctor dr=null;
		if(email !=null && pass != null) {
		 dr= ds.findByEmailAndPassword(email, pass);
	}
		else {
			throw new Exception("incorrect credential");
		}
		return dr;
	}

}
