package demos.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import demos.spring.dao.UserDAO;
import demos.spring.exceptions.NullObjectException;
import demos.spring.exceptions.ResourceNotFoundException;
import demos.spring.model.User;


@Service
public class UserService {
	@Autowired
	private UserDAO user;
	
	public List<User> getAllUser(){
		List<User> users=new ArrayList<User>();
		Iterable<User> it=user.findAll();
		it.forEach((usr)->{
			users.add(usr);
		});
		return users;
	}
public User add(User user1) {
	
	if(user1==null) {
		throw new NullObjectException("Userobject is null in user method");
		
		
	}
	return user.save(user1);
}
public User getUserById(int id) {
	Optional<User> opt=user.findById(id);
	User u1=null;
	if(opt.isPresent()) {
		u1=opt.get();
	}
	return u1;
}

public User update(User user1) {
	if(user1==null) {
		throw new NullObjectException("Userobject is null in user method");
		
		
	}
	Optional<User> opt=user.findById(user1.getUserId());
	User u1=null;
	if(opt.isPresent()) {
		u1=user.save(user1);
	}
	else {
		
	
		throw new ResourceNotFoundException("no object with id"+user1.getUserId()+"found");
	}
	return u1;
}

public void delete(int userId) {
	Optional<User> opt=user.findById(userId);
	User u1=null;
	if(opt.isPresent()) {
		u1=opt.get();
		user.delete(u1);
	}
	else {
		
	
		throw new ResourceNotFoundException("no object with id"+u1+"found");
	}
	
}
public User findByEmailAndPassword(String email,String password) {
  return user.findByEmailAndPassword(email, password);
//	return (User) user;

}
}

