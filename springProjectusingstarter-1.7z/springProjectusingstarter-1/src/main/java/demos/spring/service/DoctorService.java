package demos.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import demos.spring.dao.DoctorDAO;
import demos.spring.exceptions.NullObjectException;
import demos.spring.exceptions.ResourceNotFoundException;
import demos.spring.model.Doctor;
import demos.spring.model.User;
@Service
public class DoctorService {
	@Autowired
	private DoctorDAO dao;
	
	public List<Doctor> getAllDoctor(){
		List<Doctor> doctors=new ArrayList<Doctor>();
		Iterable<Doctor> it= dao.findAll();
		it.forEach((usr)->{
			doctors.add(usr);
		});
		return doctors;
	}
	public Doctor add(Doctor doctor) {
		if(doctor==null) {
			throw new NullObjectException("Userobject is null in user method");
			
			
		}
		return dao.save(doctor);
	}
	public Doctor getDoctorById(int id) {
		Optional<Doctor> opt=dao.findById(id);
		Doctor u1=null;
		if(opt.isPresent()) {
			u1=opt.get();
		}
		return u1;
	}

	public Doctor update(Doctor doctor) {
		if(doctor==null) {
			throw new NullObjectException("Userobject is null in doctor method");
			
			
		}
		Optional<Doctor> opt=dao.findById(doctor.getdId());
		Doctor u1=null;
		if(opt.isPresent()) {
			u1=dao.save(doctor);
		}
		else {
			
		
			throw new ResourceNotFoundException("no object with id"+doctor.getdId()+"found");
		}
		return u1;
	}

	public void delete(int dId) {
		Optional<Doctor> opt=dao.findById(dId);
		Doctor u1=null;
		if(opt.isPresent()) {
			u1=opt.get();
			dao.delete(u1);
		}
		else {
			
		
			throw new ResourceNotFoundException("no object with id"+u1+"found");
		}
		
	}
	public Doctor findByEmailAndPassword(String email,String password) {
	  return dao.findByEmailAndPassword(email, password);
//		return (User) user;

	}
	}

	


