package demos.spring.dao;

import org.springframework.data.repository.CrudRepository;

import demos.spring.model.Doctor;
import demos.spring.model.User;

public interface DoctorDAO extends CrudRepository<Doctor,Integer>{

	public Doctor findByEmailAndPassword(String email, String password);

}
