package demos.spring.dao;

import org.springframework.data.repository.CrudRepository;

import demos.spring.model.User;

public interface UserDAO extends CrudRepository<User,Integer>{

//	void deleteById(Long id);
	public User findByEmailAndPassword(String email,String password);

	//void findByEmailAndPassword(String email, String password);

}
