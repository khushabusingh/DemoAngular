package demos.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectusingstarter1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectusingstarter1Application.class, args);
	}

}
