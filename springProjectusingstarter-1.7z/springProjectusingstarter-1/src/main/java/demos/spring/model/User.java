package demos.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="patience")
public class User {
	@Id
	@Column(name="userId",scale=10)
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="user_userId_seq")
	private int userId;
	@Column(name="name" ,length=30)
	private String name;
	@Column(name="address",length=30)
	private String address;
	@Column(name="mobileNumber",scale=10)
	private String mobileNumber;
	@Column(name="email")
	private String email; 
	@Column(name="password")
	private String password;
public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	//	@Column(name="aadhar")
//	private int aadhar;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int userId, String name, String address, String mobileNumber,String email,String password) {
		super();
		this.userId = userId;
		this.name = name;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.email=email;
		this.password=password;
		//this.aadhar = aadhar;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
//	public int getAadhar() {
//		return aadhar;
//	}
//	public void setAadhar(int aadhar) {
//		this.aadhar = aadhar;
//	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", address=" + address + ", mobileNumber=" + mobileNumber +",email="+email+",password="+password+"]";
	}
	

}
