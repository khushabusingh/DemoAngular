package demos.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="doctor")
public class Doctor {
	@Id
	@Column(name="dId",scale=10)
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="doctor_dId_seq")
	private int dId;
	@Column(name="dname" ,length=20)
	private String dname;
	@Column(name="qualification",length=10)
	private String qualification;
	@Column(name="mobileNumber",scale=10)
	private String mobileNumber;
	@Column(name="email" ,unique = true)
	private String email;
	@Override
	public String toString() {
		return "Doctor [dId=" + dId + ", dname=" + dname + ", qualification=" + qualification + ", mobileNumber="
				+ mobileNumber + ", email=" + email + ", password=" + password + "]";
	}
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column(name="password")
	private String password;

}
