export class Patience{
    constructor(
        public did : string,
        public dname: string, 
         //public lname: string,  
         public qualification:string,
         //public address: string, 
         public mobileNumber: string,
         public email: string,
        public password: string,
    ){}
}