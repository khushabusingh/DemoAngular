import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patience',
  templateUrl: './patience.component.html',
  styleUrls: ['./patience.component.css']
})
export class PatienceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
