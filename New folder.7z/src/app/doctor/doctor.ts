export class Doctor {
    constructor(
        public pid : string,
        public name: string, 
         //public lname: string,  
         public address: string, 
         public mobileNumber: string,
         public email: string,
        public password: string,
      
       
        // public dateofbirth: string,
        // public gender: string,
      
  

    ) {}
}
