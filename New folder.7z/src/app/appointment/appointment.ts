

export class appointment{
     constructor(
     private id:String,
     private date:Date,
     private time:Date,
     private doctorName:String){}
}